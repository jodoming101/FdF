/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   parsing.c                                        .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: gaennuye <gaennuye@student.le-101.fr>      +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/03/25 13:51:54 by gaennuye     #+#   ##    ##    #+#       */
/*   Updated: 2018/03/25 17:05:53 by gaennuye    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "fdf.h"

int check_map(char **tab)
{
    int i;
    int cw;

    i = 1;
    cw = ft_count_words(tab[0], ' ');
    while (tab[i])
    {
        if (ft_count_words(tab[i], ' ') != cw)
            return (-1);
        i++;
    }
    return (cw);
}


t_coord  **stock_map(const char **split)
{
    int     i;
    int     j;
    char    **cw;
    int     k;
    t_coord **tab;

    i = 0;
    while (split[i])
         i++;
    if (!(tab = malloc(sizeof(*tab) * i + 1)))
        return (NULL);
    i = 0;
    j = 0;
    while(split[i])
    {
       if (!(tab[i] = malloc(sizeof(**tab) * ft_count_words(split[i], ' '))))
            return (NULL);
        cw = ft_strsplit(split[i], ' ');
        j = 0;
        while(cw[j])
        {
            tab[i][j].h = ft_atoi(cw[j]);
            j++;
        }
        i++;
    }
    tab[i] = NULL;
    return (tab);
}

int ft_parse(int fd)
{
    t_read      *tmp;
    char        **split;
    int         cw;
    t_coord     **coord_tab;

    if (!(tmp = ft_reader(fd)))
        return (2);
    if (!(split = ft_strsplit(tmp->str, '\n')))
        return (2);
/*    int i = 0;
    while (split[i])
    {
        printf("%s\n", split[i]);
        i++;
    }*/
    if ((cw = check_map(split)) == -1)
    {
        ft_putstr_fd("Invalid map\n", 2);
        return (3);
    }
    coord_tab = stock_map((const char **)split);
    printf("%d\n", coord_tab[3][3].h);
    return (0);
}

int main(int argc, char **argv)
{
    int fd;

    if (argc <= 1)
    {
    //    usage();
        return (1);
    }
    fd = open(argv[1], O_RDONLY);
    if (fd <= -1)
    {
        ft_putstr_fd("Can not open file\n", 2);
        return (1);
    }
    ft_parse(fd);
}