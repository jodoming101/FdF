/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   reader.c                                         .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: gaennuye <gaennuye@student.le-101.fr>      +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/03/21 14:53:16 by gaennuye     #+#   ##    ##    #+#       */
/*   Updated: 2018/03/21 17:57:01 by gaennuye    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "fdf.h"

static int	word_count(char *str, char c)
{
	int i;
	int number_words;

	i = 0;
	number_words = 0;
	while (str[i] != 0)
	{
		if (str[i] != c)
		{
			number_words++;
			while (str[i] != 0 && str[i] != c)
				i++;
		}
		if (str[i] != 0)
			i++;
	}
	return (number_words);
}

int check_map(t_read *fada)
{
    int i;
    int j;
    char **split;

    if (fada == NULL)
        return (0);
    split = ft_strsplit(fada->str, '\n', '\n');
    i = 1;

    j = word_count(split[0], ' ');
    while (split[i])
    {
        if (word_count(split[i], ' ') != j)
        {
            free(split);
            return (0);
        }
        i++;
    }
    free(split);
    return (1);
}

t_read			*reader(int fd)
{
	int		i;
	int		ret;
	char	*tmp;
	char	*buf;
	t_read	*lu;

	if (!(buf = (char *)malloc(sizeof(char) * BUFF_SIZE + 1)))
		return (NULL);
	if (!(lu = (t_read *)malloc(sizeof(t_read))))
		return (NULL);
	i = 0;
	while ((ret = read(fd, buf, BUFF_SIZE)))
	{
		buf[ret] = '\0';
		if (i == 0)
			tmp = ft_strdup(buf);
		else
			tmp = ft_strjoin2(tmp, buf);
		i++;
	}
	free(buf);
	lu->str = tmp;
	lu->rd = ret;
	return (lu);
}

int main(int argc, char **argv)
{
    int i = 0;
    int fd;
    t_read *fada;
    char **split;
    
    fd = open(argv[1] , O_RDONLY);
    if (fd < 0)
    {
        printf("Couldn't open file\n");
        return (0);
    }
    fada = reader(fd);
    if (fada->rd < 0)
    {
        printf("Couldn't read file");
        return (0);
    }
    if (!check_map(fada))
    {
        printf("CHeck youR mAp bItcH");
        return (0);
    }
    split = ft_strsplit(fada->str, '\n', ' ');
    while (split[i])
    {
        printf("%s\n", split[i]);
        i++;
    }
}