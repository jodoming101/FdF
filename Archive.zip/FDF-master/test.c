/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   test.c                                           .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: gaennuye <gaennuye@student.le-101.fr>      +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/03/19 18:49:02 by gaennuye     #+#   ##    ##    #+#       */
/*   Updated: 2018/03/21 13:45:18 by gaennuye    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "minilibx_macos/mlx.h"
#include <stdlib.h>

void	line(void *mlx_ptr, void *win_ptr, int xi, int yi, int xf, int yf)
{
	int dx, dy, i, xinc, yinc, cumul, x, y;

	x = xi ;
	y = yi ;
	dx = xf - xi ;
	dy = yf - yi ;
	xinc = ( dx > 0 ) ? 1 : -1 ;
	yinc = ( dy > 0 ) ? 1 : -1 ;
	dx = abs(dx) ;
	dy = abs(dy) ;
	mlx_pixel_put(mlx_ptr, win_ptr, x, y, 255000255);
	if ( dx >= dy )
	{
		cumul = dx / 2 ;
		for ( i = 1 ; i <= dx ; i++ )
		{
			x += xinc ;
			cumul += dy ;
			if ( cumul >= dx )
			{
				cumul -= dx ;
				y += yinc ;
			}
			mlx_pixel_put(mlx_ptr, win_ptr, x, y, 255000255);
		}
	}
	else
	{
		cumul = dy / 2 ;
		for ( i = 1 ; i <= dy ; i++ )
		{
			y += yinc ;
			cumul += dx ;
			if ( cumul >= dy )
			{
				cumul -= dy ;
				x += xinc ;
			}
		}
	}
}

int main()
{
	void	*mlx_ptr;
	void	*win_ptr;
	int i = 250;
	int j = 100;

	mlx_ptr = mlx_init();
	win_ptr = mlx_new_window(mlx_ptr, 500, 500, "bonjour les amis");

	line(mlx_ptr, win_ptr, 300, 300, 400, 400);

	mlx_loop(mlx_ptr);
}
