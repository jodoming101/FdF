/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   main.c                                           .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: jodoming <marvin@le-101.fr>                +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/04/16 05:36:32 by jodoming     #+#   ##    ##    #+#       */
/*   Updated: 2018/04/16 20:13:03 by jodoming    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "./incl/fdf.h"

int		main(int ac, char **av)
{
	if (ac < 2)
		ft_putstr("\nUsage : ./fdf [MAP]\n");
	else
	{
		int		fd;

		fd = open(av[1], O_RDONLY);
		get_next_line(fd,**d_map);
	}
}
