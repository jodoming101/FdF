/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   parser.c                                         .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: jodoming <marvin@le-101.fr>                +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/04/16 16:48:17 by jodoming     #+#   ##    ##    #+#       */
/*   Updated: 2018/04/16 17:00:59 by jodoming    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "./incl/fdf.h"

t_map		*new_map(char **dmap, int h, int w)
{
	t_map	*ret;
	if((ret = malloc(sizeof (t_map))) == NULL)
			return (NULL);
	ret->h = h;
	ret->w = w;
	ret->d_map = dmap;
	return (ret);
}
