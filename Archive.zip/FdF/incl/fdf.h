/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   fdf.h                                            .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: jodoming <marvin@le-101.fr>                +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/04/16 05:02:22 by jodoming     #+#   ##    ##    #+#       */
/*   Updated: 2018/04/16 20:13:06 by jodoming    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#ifndef FDF_H
# define FDF_H

# include "../minilibx_macos/mlx.h"
# include "../libft/libft.h"
# include <math.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>

typedef	struct		s_map
{
	char	**d_map;	//map data
	int		h;			//height
	int		w;			//widht
}					t_map;

typedef struct		s_launcher
{
	t_map	*map;
}					t_launcher;

t_map				*new_map(char **dmap, int h, int w);

#endif
